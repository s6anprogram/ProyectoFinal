<?php
 
require_once 'proveedores_modelo.php';
$datos = $_GET;
switch ($_GET['accion']){
    case 'editar':
        $proveedores = new Proveedores();
		$resultado = $proveedores->editar($datos);
        $respuesta = array(
                'respuesta' => $resultado
            );
        echo json_encode($respuesta);
        break;
    case 'nuevo':
        $proveedores = new Proveedores();
		$resultado = $proveedores->nuevo($datos);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;
    case 'borrar':
		$proveedores = new Proveedores();
		$resultado = $proveedores->borrar($datos['codigo']);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'consultar':
        $proveedores = new Proveedores();
        $proveedores->consultar($datos['codigo']);

        if($proveedores->getprove_cod() == null) {
            $respuesta = array(
                'respuesta' => 'no existe'
            );
        }  else {
            $respuesta = array(
                'codigo' => $proveedores->getprove_cod(),
                'nombre' => $proveedores->getprove_nomb(),
                'telefono' => $proveedores->getprove_tel(),
                'direccion' => $proveedores->getprove_dir(),
                'correo' => $proveedores->getprove_correo(),
                'respuesta' =>'existe'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'listar':
        $proveedores = new Proveedores();
        $listado = $proveedores->lista();        
        echo json_encode(array('data'=>$listado), JSON_UNESCAPED_UNICODE);
        break;

        case 'listar2':
        $variable = 0;
        $proveedores = new proveedores();
        $listado = $proveedores->lista2($variable);        
        echo json_encode(array('data'=>$listado), JSON_UNESCAPED_UNICODE);
        break;
}
?>
