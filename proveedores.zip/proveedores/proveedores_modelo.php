<?php
	require_once('../modeloAbstractoDB.php');
	class Proveedores extends ModeloAbstractoDB {
		private $prove_cod;
		private $prove_nomb;
		private $prove_tel;
		private $prove_dir;
		private $prove_correo;
		
		function __construct() {
			//$this->db_name = '';
		}
		
		public function getprove_cod(){
			return $this->prove_cod;
		}

		public function getprove_nomb(){
			return $this->prove_nomb;
		}
		
		public function getprove_tel(){
			return $this->prove_tel;
		}   

		public function getprove_dir(){
			return $this->prove_dir;
		}
		
		public function getprove_correo(){
			return $this->prove_correo;
		}              

		public function consultar($prove_cod='') {
			if($prove_cod != ''):
				$this->query = "
				SELECT prove_cod, prove_nomb, prove_tel, prove_dir, prove_correo  
				FROM tb_proveedores
				WHERE prove_cod = '$prove_cod' order by prove_cod
				";
				$this->obtener_resultados_query();
			endif;
			if(count($this->rows) == 1):
				foreach ($this->rows[0] as $propiedad=>$valor):
					$this->$propiedad = $valor;
				endforeach;
			endif;
		}
		
		public function lista() {
			$this->query = "
			SELECT prove_cod, prove_nomb, prove_tel, prove_dir, prove_correo  
			FROM tb_proveedores
            ORDER BY prove_cod
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}

		public function lista2($variable) {
			$this->query = "
			SELECT usu_cod, usu_nomb, usu_correo, usu_tel, rol_nomb 
            FROM tb_usuarios as s
            INNER JOIN tb_roles as r ON (s.rol_cod = r.rol_cod)
            where usu_cod = $variable 
            ORDER BY usu_cod
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}

		
		public function nuevo($datos=array()) {
			if(array_key_exists('prove_cod', $datos)):
				foreach ($datos as $campo=>$valor):
					$$campo = $valor;
				endforeach;
				$this->query = "
				INSERT INTO tb_proveedores
				(prove_nomb,prove_tel,prove_dir,prove_correo)
				VALUES
				('$prove_nomb','$prove_tel', '$prove_dir','$prove_correo')
				";
				$resultado = $this->ejecutar_query_simple();
				return $resultado;
			endif;
		}
		
		public function editar($datos=array()) {
			foreach ($datos as $campo=>$valor):
				$$campo = $valor;
			endforeach;
			$this->query = "
			UPDATE tb_proveedores
			SET prove_nomb='$prove_nomb',
			prove_tel='$prove_tel',
			prove_dir='$prove_dir',
			prove_correo='$prove_correo'  
			WHERE prove_cod = '$prove_cod'
			";
			$resultado = $this->ejecutar_query_simple();
			return $resultado;
		}
		
		public function borrar($prove_cod='') {
			$this->query = "
			DELETE FROM tb_proveedores
			WHERE prove_cod = '$prove_cod'
			";
			$resultado = $this->ejecutar_query_simple();

			return $resultado;
		}
		
		function __destruct() {
			//unset($this);
		}
	}
?>