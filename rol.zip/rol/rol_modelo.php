<?php
	require_once('../modeloAbstractoDB.php');
	class Roles extends ModeloAbstractoDB {
		private $rol_cod;
		private $rol_nomb;
		private $rol_desc;
		
		function __construct() {
			//$this->db_nomb = '';
		}
		
		public function getrol_cod(){
			return $this->rol_cod;
		}

		public function getrol_nomb(){
			return $this->rol_nomb;
		}

		public function getrol_desc(){
			return $this->rol_desc;
		}

		
          

		public function consultar($rol_cod='') {
			if($rol_cod != ''):
				$this->query = "
				SELECT rol_cod, rol_nomb, rol_desc 
				FROM tb_roles
				WHERE rol_cod = '$rol_cod' order by rol_cod";
				
				$this->obtener_resultados_query();
			endif;
			if(count($this->rows) == 1):
				foreach ($this->rows[0] as $propiedad=>$valor):
					$this->$propiedad = $valor;
				endforeach;
			endif;
		}
		
		public function lista() {
			$this->query = "
			SELECT rol_cod, rol_nomb, rol_desc
			FROM tb_roles
            ORDER BY rol_cod
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}

		public function lista2($variable) {
			$this->query = "
			SELECT usu_cod, usu_nomb, usu_correo, usu_tel, rol_nomb 
            FROM tb_usuarios as s
            INNER JOIN tb_roles as r ON (s.rol_cod = r.rol_cod)
            where usu_cod = $variable 
            ORDER BY usu_cod
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}
		
		public function nuevo($datos=array()) {
			if(array_key_exists('rol_cod', $datos)):
				foreach ($datos as $campo=>$valor):
					$$campo = $valor;
				endforeach;
				$this->query = "
				INSERT INTO tb_roles
				(rol_nomb,rol_desc)
				VALUES
				('$rol_nomb','$rol_desc')
				";
				$resultado = $this->ejecutar_query_simple();
				return $resultado;
			endif;
		}
		
		public function editar($datos=array()) {
			foreach ($datos as $campo=>$valor):
				$$campo = $valor;
			endforeach;
			$this->query = "
			UPDATE tb_roles
			SET rol_nomb='$rol_nomb',
			rol_desc='$rol_desc'
			WHERE rol_cod = '$rol_cod'
			";
			$resultado = $this->ejecutar_query_simple();
			return $resultado;
		}
		
		public function borrar($rol_cod='') {
			$this->query = "
			DELETE tb_roles
			WHERE rol_cod = '$rol_cod'
			";
			$resultado = $this->ejecutar_query_simple();

			return $resultado;
		}
		
		function __destruct() {
			//unset($this);
		}
	}
?>