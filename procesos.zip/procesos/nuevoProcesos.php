<!-- quick email widget -->
<div id="seccion-procesos">
	<div class="box-header">
    	<i class="fa fa-building" aria-hidden="true">Gestión de Procesos</i>
        <!-- tools box -->
        <div class="pull-right box-tools">
        	<button class="btn btn-info btn-sm btncerrar2" data-toggle="tooltip" title="Cerrar"><i class="fa fa-times"></i></button>
        </div><!-- /. tools -->
    </div>
    <div class="box-body">

		<div align ="center">
				<div id="actual"> 
				</div>
		</div>


        <div class="panel-group"><div class="panel panel-info">
            <div class="panel-heading">Datos</div>
            <div class="panel-body">
    
                <form class="form-horizontal" role="form"  id="fprocesos">


 					<div class="form-group">
                        <label class="control-label col-sm-2" for="proce_cod">Codigo:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="proce_cod" name="proce_cod" placeholder="Ingrese Codigo"
                            value = "" readonly="true"  data-validation="length alphanumeric" data-validation-length="3-12">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-sm-2" for="proce_nomb">Proceso:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="proce_nomb" name="proce_nomb" placeholder="Ingrese el nombre de Proceso"
                            value = "">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-sm-2" for="proce_desc">Descripcion:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="proce_desc" name="proce_desc" placeholder="Ingrese Descripcion del Proceso"
                            value = "">
                        </div>
                    </div>

					 <div class="form-group">        
                        <div class="col-sm-offset-2 col-sm-10">
                            <button type="button" id="grabar" class="btn btn-info" data-toggle="tooltip" title="Grabar Proceso">Grabar Proceso</button>
                            <button type="button" id="cerrar" class="btn btn-success btncerrar2" data-toggle="tooltip" title="Cancelar">Cancelar</button>
                        </div>
                    </div>

					<input type="hidden" id="nuevo" value="nuevo" name="accion"/>
			</fieldset>

		</form>
	</div>
</div>