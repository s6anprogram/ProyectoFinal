<?php
	require_once('../modeloAbstractoDB.php');
	class Procesos extends ModeloAbstractoDB {
		private $proce_cod;
		private $proce_nomb;
		private $proce_desc;
		
		function __construct() {
			//$this->db_name = '';
		}
		
		public function getproce_cod(){
			return $this->proce_cod;
		}

		public function getproce_nomb(){
			return $this->proce_nomb;
		}
		
		public function getproce_desc(){
			return $this->proce_desc;
		}                

		public function consultar($proce_cod='') {
			if($proce_cod != ''):
				$this->query = "
				SELECT proce_cod, proce_nomb, proce_desc 
				FROM tb_procesos
				WHERE proce_cod = '$proce_cod' order by proce_cod
				";
				$this->obtener_resultados_query();
			endif;
			if(count($this->rows) == 1):
				foreach ($this->rows[0] as $propiedad=>$valor):
					$this->$propiedad = $valor;
				endforeach;
			endif;
		}
		
		public function lista() {
			$this->query = "
			SELECT proce_cod, proce_nomb, proce_desc
			FROM tb_procesos
            ORDER BY proce_cod
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}

		public function lista2($variable) {
			$this->query = "
			SELECT usu_cod, usu_nomb, usu_correo, usu_tel, rol_nomb 
            FROM tb_usuarios as s
            INNER JOIN tb_roles as r ON (s.rol_cod = r.rol_cod)
            where usu_cod = $variable 
            ORDER BY usu_cod
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}

		
		public function nuevo($datos=array()) {
			if(array_key_exists('proce_cod', $datos)):
				foreach ($datos as $campo=>$valor):
					$$campo = $valor;
				endforeach;
				$this->query = "
				INSERT INTO tb_procesos
				(proce_nomb,proce_desc)
				VALUES
				('$proce_nomb','$proce_desc')
				";
				$resultado = $this->ejecutar_query_simple();
				return $resultado;
			endif;
		}
		
		public function editar($datos=array()) {
			foreach ($datos as $campo=>$valor):
				$$campo = $valor;
			endforeach;
			$this->query = "
			UPDATE tb_procesos
			SET proce_nomb='$proce_nomb',
			proce_desc='$proce_desc' 
			WHERE proce_cod = '$proce_cod'
			";
			$resultado = $this->ejecutar_query_simple();
			return $resultado;
		}
		
		public function borrar($proce_cod='') {
			$this->query = "
			DELETE FROM tb_procesos
			WHERE proce_cod = '$proce_cod'
			";
			$resultado = $this->ejecutar_query_simple();

			return $resultado;
		}
		
		function __destruct() {
			//unset($this);
		}
	}
?>