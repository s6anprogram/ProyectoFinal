<?php
 
require_once 'procesos_modelo.php';
$datos = $_GET;
switch ($_GET['accion']){
    case 'editar':
        $procesos = new Procesos();
		$resultado = $procesos->editar($datos);
        $respuesta = array(
                'respuesta' => $resultado
            );
        echo json_encode($respuesta);
        break;
    case 'nuevo':
        $procesos = new Procesos();
		$resultado = $procesos->nuevo($datos);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;
    case 'borrar':
		$procesos = new Procesos();
		$resultado = $procesos->borrar($datos['codigo']);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'consultar':
        $procesos = new Procesos();
        $procesos->consultar($datos['codigo']);

        if($procesos->getproce_cod() == null) {
            $respuesta = array(
                'respuesta' => 'no existe'
            );
        }  else {
            $respuesta = array(
                'codigo' => $procesos->getproce_cod(),
                'procesos' => $procesos->getproce_nomb(),
                'descripcion' => $procesos->getproce_desc(),
                'respuesta' =>'existe'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'listar':
        $procesos = new Procesos();
        $listado = $procesos->lista();        
        echo json_encode(array('data'=>$listado), JSON_UNESCAPED_UNICODE);
        break;

        case 'listar2':
        $variable = 0;
        $procesos = new Procesos();
        $listado = $procesos->lista2($variable);        
        echo json_encode(array('data'=>$listado), JSON_UNESCAPED_UNICODE);
        break;
}
?>
