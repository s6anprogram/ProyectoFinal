<?php
	require_once('../modeloAbstractoDB.php');
	class Empresas extends ModeloAbstractoDB {
		private $empre_cod;
		private $empre_nomb;
		private $empre_rep;
		private $empre_dir;
		private $empre_tel;
		private $empre_correo;
		private $ciu_cod;
		
		function __construct() {
			//$this->db_name = '';
		}
		
		public function getempre_cod(){
			return $this->empre_cod;
		}

		public function getempre_nomb(){
			return $this->empre_nomb;
		}
		
		public function getempre_rep(){
			return $this->empre_rep;
		} 

		public function getempre_dir(){
			return $this->empre_dir;
		}  

		public function getempre_tel(){
			return $this->empre_tel;
		}   
		
		public function getempre_correo(){
			return $this->empre_correo;
		}  

		public function getciu_cod(){
			return $this->ciu_cod;
		}  

		public function consultar($empre_cod='') {
			if($empre_cod != ''):
				$this->query = "
				SELECT empre_cod, empre_nomb, empre_rep, empre_dir, empre_tel, empre_correo, ciu_cod 
				FROM tb_empresas 
				WHERE empre_cod = '$empre_cod'
				";
				$this->obtener_resultados_query();
			endif;
			if(count($this->rows) == 1):
				foreach ($this->rows[0] as $propiedad=>$valor):
					$this->$propiedad = $valor;
				endforeach;
			endif;
		}
		
		public function lista() {
			$this->query = "
			SELECT empre_cod, empre_nomb, empre_rep, empre_dir, empre_tel, empre_correo, c.ciu_nomb
				FROM tb_empresas as em INNER JOIN tb_ciudades as c 
				ON (em.ciu_cod = c.ciu_cod) 
				ORDER BY empre_cod
				";
			$this->obtener_resultados_query();
			return $this->rows;
		}

		public function lista2($variable) {
			$this->query = "
			SELECT empre_cod, empre_nomb, empre_rep, empre_dir, empre_tel, empre_correo, c.ciu_nomb
				FROM tb_empresas as em INNER JOIN tb_ciudades as c 
				ON (em.ciu_cod = c.ciu_cod) 
				ORDER BY empre_cod
				";
			$this->obtener_resultados_query();
			return $this->rows;
		}
		
		public function nuevo($datos=array()) {
			if(array_key_exists('empre_cod', $datos)):
				foreach ($datos as $campo=>$valor):
					$$campo = $valor;
				endforeach;
				$this->query = "
				INSERT INTO tb_empresas
				(empre_nomb,empre_rep,empre_dir,empre_tel,empre_correo,ciu_cod)
				VALUES
				('$empre_nomb','$empre_rep','$empre_dir','$empre_tel','$empre_correo','$ciu_cod')
				";
				$resultado = $this->ejecutar_query_simple();
				return $resultado;
			endif;
		}
		
		public function editar($datos=array()) {
			foreach ($datos as $campo=>$valor):
				$$campo = $valor;
			endforeach;
			$this->query = "
			UPDATE tb_empresas
			SET empre_nomb='$empre_nomb',
			empre_rep='$empre_rep',
			empre_dir='$empre_dir',
			empre_tel='$empre_tel',
			empre_correo='$empre_correo',
			ciu_cod='$ciu_cod'
			WHERE empre_cod  = '$empre_cod '
			";
			$resultado = $this->ejecutar_query_simple();
			return $resultado;
		}
		
		public function borrar($empre_cod='') {
			$this->query = "
			DELETE FROM tb_empresas
			WHERE empre_cod = '$empre_cod'
			";
			$resultado = $this->ejecutar_query_simple();

			return $resultado;
		}
		
		function __destruct() {
			//unset($this);
		}
	}
?>