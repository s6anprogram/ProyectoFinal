<?php
 
require_once 'empresas_modelo.php';
$datos = $_GET;
switch ($_GET['accion']){
    case 'editar':
        $empresas = new Empresas();
		$resultado = $empresas->editar($datos);
        $respuesta = array(
                'respuesta' => $resultado
            );
        echo json_encode($respuesta);
        break;
    case 'nuevo':
        $empresas = new Empresas();
		$resultado = $empresas->nuevo($datos);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;
    case 'borrar':
		$empresas = new Empresas();
		$resultado = $empresas->borrar($datos['codigo']);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'consultar':
        $empresas = new Empresas();
        $empresas->consultar($datos['codigo']);

        if($empresas->getempre_cod() == null) {
            $respuesta = array(
                'respuesta' => 'no existe'
            );
        }  else {
            $respuesta = array(
                'codigo' => $empresas->getempre_cod(),
                'nombre' => $empresas->getempre_nomb(),
                'representante' =>$empresas->getempre_rep(),
                'direccion' =>$empresas->getempre_dir(),
                'telefono' =>$empresas->getempre_tel(),
                'correo' =>$empresas->getempre_correo(),
                'ciudad' =>$empresas->getciu_cod(),
                'respuesta' =>'existe'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'listar':
        $empresas = new Empresas();
        $listado = $empresas->lista();        
        echo json_encode(array('data'=>$listado), JSON_UNESCAPED_UNICODE);
        break;

        case 'listar2':
        $variable = 0;
        $empresas = new Empresas();
        $listado = $empresas->lista2($variable);        
        echo json_encode(array('data'=>$listado), JSON_UNESCAPED_UNICODE);
        break;
}
?>
