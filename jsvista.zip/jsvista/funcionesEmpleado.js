  var dt;

function empleado(){
    $("#contenido").on("click","button#actualizar",function(){
         var datos=$("#fempleado").serialize();
         $.ajax({
            type:"get",
            url:"./php/empleado/controladorEmpleado.php",
            data: datos,
            dataType:"json"
          }).done(function( resultado ) {
              if(resultado.respuesta){
                swal(
                    'Actualizado!',
                    'Se actualizaron los datos correctamente',
                    'success'
                )     
                dt.ajax.reload();
                $("#titulo").html("Listado Empleados");
                $("#nuevo-editar").html("");
                $("#nuevo-editar").removeClass("show");
                $("#nuevo-editar").addClass("hide");
                $("#empleado").removeClass("hide");
                $("#empleado").addClass("show");
             } else {
                swal({
                  type: 'error',
                  title: 'Oops...',
                  text: 'Something went wrong!'                         
                })
            }
        });
    })

    $("#contenido").on("click","a.borrar",function(){
        //Recupera datos del formulario
        var codigo = $(this).data("codigo");

        swal({
              title: '¿Está seguro?',
              text: "¿Realmente desea borrar el empleado con codigo : " + codigo + " ?",
              type: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Si, Borrarlo!'
        }).then((decision) => {
                if (decision.value) {

                    var request = $.ajax({
                        method: "get",
                        url: "./php/empleado/controladorEmpleado.php",
                        data: {codigo: codigo, accion:'borrar'},
                        dataType: "json"
                    })

                    request.done(function( resultado ) {
                        if(resultado.respuesta == 'correcto'){
                            swal(
                                'Borrado!',
                                'El empleado con codigo : ' + codigo + ' fue borrado',
                                'success'
                            )     
                            dt.ajax.reload();                            
                        } else {
                            swal({
                              type: 'error',
                              title: 'Oops...',
                              text: 'Something went wrong!'                         
                            })
                        }
                    });
                     
                    request.fail(function( jqXHR, textStatus ) {
                        swal({
                          type: 'error',
                          title: 'Oops...',
                          text: 'Something went wrong!' + textStatus                          
                        })
                    });
                }
        })

    });

    $("#contenido").on("click","button.btncerrar2",function(){
        $("#titulo").html("Listado Empleados");
        $("#nuevo-editar").html("");
        $("#nuevo-editar").removeClass("show");
        $("#nuevo-editar").addClass("hide");
        $("#empleado").removeClass("hide");
        $("#empleado").addClass("show");

    })

    $("#contenido").on("click","button.btncerrar",function(){
        $("#contenedor").removeClass("show");
        $("#contenedor").addClass("hide");
        $("#contenido").html('');
    })

    $("#contenido").on("click","button#nuevo",function(){
        $("#titulo").html("Nuevo Empleado");
        var rol;
        $("#nuevo-editar" ).load("./php/empleado/nuevoEmpleado.php"); 
        $("#nuevo-editar").removeClass("hide");
        $("#nuevo-editar").addClass("show");
        $("#empleado").removeClass("show");
        $("#empleado").addClass("hide");
        $.ajax({
            type:"get",
            url:"./php/procesos/controladorProcesos.php",
            data: {accion:'listar'},
            dataType:"json"
          }).done(function( resultado ) {   
             //console.log(resultado.data)           
             $("#proce_cod option").remove()       
             $("#proce_cod").append("<option selecte value=''>Seleccione un Proceso</option>")
             $.each(resultado.data, function (index, value) { 
               $("#proce_cod").append("<option value='" + value.proce_cod + "'>" + value.proce_nomb + "</option>")
             });
          });  
          $.ajax({
            type:"get",
            url:"./php/sucursales/controladorSucursales.php",
            data: {accion:'listar'},
            dataType:"json"
          }).done(function( resultado ) {   
             //console.log(resultado.data)           
             $("#sucur_cod option").remove()       
             $("#sucur_cod").append("<option selecte value=''>Seleccione una Sucursal</option>")
             $.each(resultado.data, function (index, value) { 
               $("#sucur_cod").append("<option value='" + value.sucur_cod + "'>" + value.sucur_nomb + "</option>")
             });
          }); 
    })

    $("#contenido").on("click","button#grabar",function(){
        /*var comu_codi = $("#comu_codi").attr("value");
        var comu_nomb = $("#comu_nomb").attr("value");
        var muni_codi = $("#muni_codi").attr("value");
        var datos = "comu_codi="+comu_codi+"&comu_nomb="+comu_nomb+"&muni_codi="+muni_codi;*/
      
      var datos=$("#fempleado").serialize();
       $.ajax({
            type:"get",
            url:"./php/empleado/controladorEmpleado.php",
            data: datos,
            dataType:"json"
          }).done(function( resultado ) {
              if(resultado.respuesta){
                swal(
                    'Grabado!!',
                    'El registro se grabó correctamente',
                    'success'
                )     
                dt.ajax.reload();
                $("#titulo").html("Listado Empleados");
                $("#nuevo-editar").html("");
                $("#nuevo-editar").removeClass("show");
                $("#nuevo-editar").addClass("hide");
                $("#empleado").removeClass("hide");
                $("#empleado").addClass("show");
             } else {
                swal({
                  type: 'error',
                  title: 'Oops...',
                  text: 'Something went wrong!'                         
                })
            }
        });
    });


    $("#contenido").on("click","a.editar",function(){
       $("#titulo").html("Editar Empleado");
       //Recupera datos del fromulario
       var codigo = $(this).data("codigo");
       var proceso;
       var sucursal;
        $("#nuevo-editar").load("./php/empleado/editarEmpleado.php");
        $("#nuevo-editar").removeClass("hide");
        $("#nuevo-editar").addClass("show");
        $("#empleado").removeClass("show");
        $("#empleado").addClass("hide");
       $.ajax({
           type:"get",
           url:"./php/empleado/controladorEmpleado.php",
           data: {codigo: codigo, accion:'consultar'},
           dataType:"json"
           }).done(function( empleado ) {        
                if(empleado.respuesta === "no existe"){
                    swal({
                      type: 'error',
                      title: 'Oops...',
                      text: 'El empleado no existe!!!!!'                         
                    })
                } else {
                    $("#emple_cod").val(empleado.codigo);                   
                    $("#emple_nomb").val(empleado.nombre);               
                    $("#emple_edad").val(empleado.edad);    
                    $("#emple_tel").val(empleado.telefono);
                    $("#emple_dir").val(empleado.direccion);
                    $("#emple_correo").val(empleado.correo);    
                    proceso = empleado.proceso;    
                    sucursal = empleado.sucursal;                   
                }
           });  
           
           $.ajax({
            type:"get",
            url:"./php/procesos/controladorProcesos.php",
            data: {accion:'listar'},
            dataType:"json"
          }).done(function( resultado ) {                     
             $("#proce_cod option").remove();
             $.each(resultado.data, function (index, value) { 
               
               if(proceso === value.proce_cod){
                 $("#proce_cod").append("<option selected value='" + value.proce_cod + "'>" + value.proce_nomb + "</option>")
               }else {
                 $("#proce_cod").append("<option value='" + value.proce_cod + "'>" + value.proce_nomb + "</option>")
               }
             });
            });
          $.ajax({
            type:"get",
            url:"./php/sucursales/controladorSucursales.php",
            data: {accion:'listar'},
            dataType:"json"
          }).done(function( resultado ) {                     
             $("#sucur_cod option").remove();
             $.each(resultado.data, function (index, value) { 
               
               if(sucursal === value.sucur_cod){
                 $("#sucur_cod").append("<option selected value='" + value.sucur_cod + "'>" + value.sucur_nomb + "</option>")
               }else {
                 $("#sucur_cod").append("<option value='" + value.sucur_cod + "'>" + value.sucur_nomb + "</option>")
               }
             });
            });

       })
}


$(document).ready(() => {
  $("#contenido").off("click", "a.editar");
  $("#contenido").off("click", "button#actualizar");
  $("#contenido").off("click","a.borrar");
  $("#contenido").off("click","button#nuevo");
  $("#contenido").off("click","button#grabar");
  $("#titulo").html("Listado de Empleados");
  dt = $("#tabla").DataTable({
        "ajax": "php/empleado/controladorEmpleado.php?accion=listar",
        "columns": [
            { "data": "emple_cod"} ,
            { "data": "emple_nomb" },
            { "data": "emple_edad" },
            { "data": "emple_tel" },
            { "data": "emple_dir" },
            { "data": "emple_correo" },
            { "data": "proce_nomb" },
            { "data": "sucur_nomb" },
        ]
  });
  empleado();
});