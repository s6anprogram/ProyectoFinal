var dt;

function empresas(){
    $("#contenido").on("click","button#actualizar",function(){
         var datos=$("#fempresas").serialize();
         $.ajax({
            type:"get",
            url:"./php/empresas/controladorEmpresas.php",
            data: datos,
            dataType:"json"
          }).done(function( resultado ) {
              if(resultado.respuesta){
                swal(
                    'Actualizado!',
                    'Se actualizaron los datos correctamente',
                    'success'
                )     
                dt.ajax.reload();
                $("#titulo").html("Listado de Empresas");
                $("#nuevo-editar").html("");
                $("#nuevo-editar").removeClass("show");
                $("#nuevo-editar").addClass("hide");
                $("#empresas").removeClass("hide");
                $("#empresas").addClass("show")
             } else {
                swal({
                  type: 'error',
                  title: 'Oops...',
                  text: 'Something went wrong!'                         
                })
            }
        });
    })

    $("#contenido").on("click","a.borrar",function(){
        //Recupera datos del formulario
        var codigo = $(this).data("codigo");

        swal({
              title: '¿Está seguro?',
              text: "¿Realmente desea borrar la empresa con codigo : " + codigo + " ?",
              type: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Si, Borrarlo!'
        }).then((decision) => {
                if (decision.value) {

                    var request = $.ajax({
                        method: "get",
                        url: "./php/empresas/controladorEmpresas.php",
                        data: {codigo: codigo, accion:'borrar'},
                        dataType: "json"
                    })

                    request.done(function( resultado ) {
                        if(resultado.respuesta == 'correcto'){
                            swal(
                                'Borrado!',
                                'La empresa con el codigo : ' + codigo + ' fue borrado',
                                'success'
                            )     
                            dt.ajax.reload();                            
                        } else {
                            swal({
                              type: 'error',
                              title: 'Oops...',
                              text: 'Something went wrong!'                         
                            })
                        }
                    });
                     
                    request.fail(function( jqXHR, textStatus ) {
                        swal({
                          type: 'error',
                          title: 'Oops...',
                          text: 'Something went wrong!' + textStatus                          
                        })
                    });
                }
        })

    });

    $("#contenido").on("click","button.btncerrar2",function(){
        $("#titulo").html("Listado de Empresas");
        $("#nuevo-editar").html("");
        $("#nuevo-editar").removeClass("show");
        $("#nuevo-editar").addClass("hide");
        $("#empresas").removeClass("hide");
        $("#empresas").addClass("show");

    })

    $("#contenido").on("click","button.btncerrar",function(){
        $("#contenedor").removeClass("show");
        $("#contenedor").addClass("hide");
        $("#contenido").html('')
    })

    $("#contenido").on("click","button#nuevo",function(){
        $("#titulo").html("Nueva Empresa");
        $("#nuevo-editar" ).load("./php/empresas/nuevoEmpresas.php"); 
        $("#nuevo-editar").removeClass("hide");
        $("#nuevo-editar").addClass("show");
        $("#empresas").removeClass("show");
        $("#empresas").addClass("hide");
         $.ajax({
             type:"get",
             url:"./php/ciudad/controladorCiudad.php",
             data: {accion:'listar'},
             dataType:"json"
           }).done(function( resultado ) {   
              //console.log(resultado.data)           
              $("#ciu_cod option").remove()       
              $("#ciu_cod").append("<option selecte value=''>Seleccione una Ciudad</option>")
              $.each(resultado.data, function (index, value) { 
                $("#ciu_cod").append("<option value='" + value.ciu_cod + "'>" + value.ciu_nomb + "</option>")
              });
           });
    })

    $("#contenido").on("click","button#grabar",function(){
        /*var comu_codi = $("#comu_codi").attr("value");
        var comu_nomb = $("#comu_nomb").attr("value");
        var muni_codi = $("#muni_codi").attr("value");
        var datos = "comu_codi="+comu_codi+"&comu_nomb="+comu_nomb+"&muni_codi="+muni_codi;*/
      
      var datos=$("#fempresas").serialize();
       $.ajax({
            type:"get",
            url:"./php/empresas/controladorEmpresas.php",
            data: datos,
            dataType:"json"
          }).done(function( resultado ) {
              if(resultado.respuesta){
                swal(
                    'Grabado!!',
                    'El registro se grabó correctamente',
                    'success'
                )     
                dt.ajax.reload();
                $("#titulo").html("Listado Empresas");
                $("#nuevo-editar").html("");
                $("#nuevo-editar").removeClass("show");
                $("#nuevo-editar").addClass("hide");
                $("#empresas").removeClass("hide");
                $("#empresas").addClass("show")
             } else {
                swal({
                  type: 'error',
                  title: 'Oops...',
                  text: 'Something went wrong!'                         
                })
            }
        });
    });


    $("#contenido").on("click","a.editar",function(){
       $("#titulo").html("Editar Empresa");
       //Recupera datos del fromulario
       var codigo = $(this).data("codigo");
       var ciudad;
        $("#nuevo-editar").load("./php/empresas/editarempresas.php");
        $("#nuevo-editar").removeClass("hide");
        $("#nuevo-editar").addClass("show");
        $("#empresas").removeClass("show");
        $("#empresas").addClass("hide");
       $.ajax({
           type:"get",
           url:"./php/empresas/controladorEmpresas.php",
           data: {codigo: codigo, accion:'consultar'},
           dataType:"json"
           }).done(function( empresas ) {        
                if(empresas.respuesta === "no existe"){
                    swal({
                      type: 'error',
                      title: 'Oops...',
                      text: 'la Direccion no existe!!!!!'                         
                    })
                } else {
                    $("#empre_cod").val(empresas.codigo);                   
                    $("#empre_nomb").val(empresas.nombre);
                    $("#empre_rep").val(empresas.representante);
                    $("#empre_dir").val(empresas.direccion);
                    $("#empre_tel").val(empresas.telefono);
                    $("#empre_correo").val(empresas.correo);
                    ciudad = empresas.ciudad;
                }
           });

           $.ajax({
             type:"get",
             url:"./php/ciudad/controladorCiudad.php",
             data: {accion:'listar'},
             dataType:"json"
           }).done(function( resultado ) {                     
              $("#ciu_cod option").remove();
              $.each(resultado.data, function (index, value) { 
                
                if(ciudad === value.ciu_cod){
                  $("#ciu_cod").append("<option selected value='" + value.ciu_cod + "'>" + value.ciu_nomb + "</option>")
                }else {
                  $("#ciu_cod").append("<option value='" + value.ciu_cod + "'>" + value.ciu_nomb + "</option>")
                }
              });
           });    
            
       })
}

$(document).ready(() => {
  $("#contenido").off("click", "a.editar");
  $("#contenido").off("click", "button#actualizar");
  $("#contenido").off("click","a.borrar");
  $("#contenido").off("click","button#nuevo");
  $("#contenido").off("click","button#grabar");
  $("#titulo").html("Listado de Empresas");
  dt = $("#tabla").DataTable({
        "ajax": "php/empresas/controladorEmpresas.php?accion=listar",
        "columns": [
            { "data": "empre_cod"} ,
            { "data": "empre_nomb"},
            { "data": "empre_rep"},
            { "data": "empre_dir"},
            { "data": "empre_tel"},
            { "data": "empre_correo"},
            { "data": "ciu_nomb" },
        ]
  });
  empresas();
});