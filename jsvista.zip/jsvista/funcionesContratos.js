  var dt;

function contratos(){
    $("#contenido").on("click","button#actualizar",function(){
         var datos=$("#fcontratos").serialize();
         $.ajax({
            type:"get",
            url:"./php/contratos/controladorContratos.php",
            data: datos,
            dataType:"json"
          }).done(function( resultado ) {
              if(resultado.respuesta){
                swal(
                    'Actualizado!',
                    'Se actualizaron los datos correctamente',
                    'success'
                )     
                dt.ajax.reload();
                $("#titulo").html("Listado Contratos");
                $("#nuevo-editar").html("");
                $("#nuevo-editar").removeClass("show");
                $("#nuevo-editar").addClass("hide");
                $("#contratos").removeClass("hide");
                $("#contratos").addClass("show");
             } else {
                swal({
                  type: 'error',
                  title: 'Oops...',
                  text: 'Something went wrong!'                         
                })
            }
        });
    })

    $("#contenido").on("click","a.borrar",function(){
        //Recupera datos del formulario
        var codigo = $(this).data("codigo");

        swal({
              title: '¿Está seguro?',
              text: "¿Realmente desea borrar el contrato con codigo : " + codigo + " ?",
              type: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Si, Borrarlo!'
        }).then((decision) => {
                if (decision.value) {

                    var request = $.ajax({
                        method: "get",
                        url: "./php/contratos/controladorContratos.php",
                        data: {codigo: codigo, accion:'borrar'},
                        dataType: "json"
                    })

                    request.done(function( resultado ) {
                        if(resultado.respuesta == 'correcto'){
                            swal(
                                'Borrado!',
                                'El contrato con codigo : ' + codigo + ' fue borrado',
                                'success'
                            )     
                            dt.ajax.reload();                            
                        } else {
                            swal({
                              type: 'error',
                              title: 'Oops...',
                              text: 'Something went wrong!'                         
                            })
                        }
                    });
                     
                    request.fail(function( jqXHR, textStatus ) {
                        swal({
                          type: 'error',
                          title: 'Oops...',
                          text: 'Something went wrong!' + textStatus                          
                        })
                    });
                }
        })

    });

    $("#contenido").on("click","button.btncerrar2",function(){
        $("#titulo").html("Listado de Contratos");
        $("#nuevo-editar").html("");
        $("#nuevo-editar").removeClass("show");
        $("#nuevo-editar").addClass("hide");
        $("#contratos").removeClass("hide");
        $("#contratos").addClass("show");

    })

    $("#contenido").on("click","button.btncerrar",function(){
        $("#contenedor").removeClass("show");
        $("#contenedor").addClass("hide");
        $("#contenido").html('');
    })

    $("#contenido").on("click","button#nuevo",function(){
        $("#titulo").html("Nuevo Contrato");
        var rol;
        $("#nuevo-editar" ).load("./php/contratos/nuevoContratos.php"); 
        $("#nuevo-editar").removeClass("hide");
        $("#nuevo-editar").addClass("show");
        $("#contratos").removeClass("show");
        $("#contratos").addClass("hide");
        $.ajax({
            type:"get",
            url:"./php/proveedores/controladorProveedores.php",
            data: {accion:'listar'},
            dataType:"json"
          }).done(function( resultado ) {   
             //console.log(resultado.data)           
             $("#prove_cod option").remove()       
             $("#prove_cod").append("<option selecte value=''>Seleccione un Proveedor</option>")
             $.each(resultado.data, function (index, value) { 
               $("#prove_cod").append("<option value='" + value.prove_cod + "'>" + value.prove_nomb + "</option>")
             });
          });  
          $.ajax({
            type:"get",
            url:"./php/empleado/controladorEmpleado.php",
            data: {accion:'listar'},
            dataType:"json"
          }).done(function( resultado ) {   
             //console.log(resultado.data)           
             $("#emple_cod option").remove()       
             $("#emple_cod").append("<option selecte value=''>Seleccione un Empleado</option>")
             $.each(resultado.data, function (index, value) { 
               $("#emple_cod").append("<option value='" + value.emple_cod + "'>" + value.sucur_nomb + "</option>")
             });
          }); 
    })

    $("#contenido").on("click","button#grabar",function(){
        /*var comu_codi = $("#comu_codi").attr("value");
        var comu_nomb = $("#comu_nomb").attr("value");
        var muni_codi = $("#muni_codi").attr("value");
        var datos = "comu_codi="+comu_codi+"&comu_nomb="+comu_nomb+"&muni_codi="+muni_codi;*/
      
      var datos=$("#fcontratos").serialize();
       $.ajax({
            type:"get",
            url:"./php/contratos/controladorContratos.php",
            data: datos,
            dataType:"json"
          }).done(function( resultado ) {
              if(resultado.respuesta){
                swal(
                    'Grabado!!',
                    'El registro se grabó correctamente',
                    'success'
                )     
                dt.ajax.reload();
                $("#titulo").html("Listado Contratos");
                $("#nuevo-editar").html("");
                $("#nuevo-editar").removeClass("show");
                $("#nuevo-editar").addClass("hide");
                $("#contratos").removeClass("hide");
                $("#contratos").addClass("show");
             } else {
                swal({
                  type: 'error',
                  title: 'Oops...',
                  text: 'Something went wrong!'                         
                })
            }
        });
    });


    $("#contenido").on("click","a.editar",function(){
       $("#titulo").html("Editar Contrato");
       //Recupera datos del fromulario
       var codigo = $(this).data("codigo");
       var proveedor;
       var empleado;
        $("#nuevo-editar").load("./php/contratos/editarContratos.php");
        $("#nuevo-editar").removeClass("hide");
        $("#nuevo-editar").addClass("show");
        $("#contratos").removeClass("show");
        $("#contratos").addClass("hide");
       $.ajax({
           type:"get",
           url:"./php/contratos/controladorContratos.php",
           data: {codigo: codigo, accion:'consultar'},
           dataType:"json"
           }).done(function( contratos ) {        
                if(contratos.respuesta === "no existe"){
                    swal({
                      type: 'error',
                      title: 'Oops...',
                      text: 'El contrato no existe!!!!!'                         
                    })
                } else {
                    $("#contra_cod").val(contratos.codigo);
                    proveedor = contratos.proveedor;    
                    empleado = contratos.empleado;                    
                    $("#contra_ini").val(contratos.inicio);               
                    $("#contra_fin").val(contratos.fin);    
                    $("#contra_desc").val(contratos.descripcion);
                                      
                }
           });  
           
           $.ajax({
            type:"get",
            url:"./php/proveedores/controladorProveedores.php",
            data: {accion:'listar'},
            dataType:"json"
          }).done(function( resultado ) {                     
             $("#prove_cod option").remove();
             $.each(resultado.data, function (index, value) { 
               
               if(proveedor === value.prove_cod){
                 $("#prove_cod").append("<option selected value='" + value.prove_cod + "'>" + value.prove_nomb + "</option>")
               }else {
                 $("#prove_cod").append("<option value='" + value.prove_cod + "'>" + value.prove_nomb + "</option>")
               }
             });
            });
          $.ajax({
            type:"get",
            url:"./php/empleado/controladorEmpleado.php",
            data: {accion:'listar'},
            dataType:"json"
          }).done(function( resultado ) {                     
             $("#emple_cod option").remove();
             $.each(resultado.data, function (index, value) { 
               
               if(empleado === value.emple_cod){
                 $("#emple_cod").append("<option selected value='" + value.emple_cod + "'>" + value.emple_nomb + "</option>")
               }else {
                 $("#emple_cod").append("<option value='" + value.emple_cod + "'>" + value.emple_nomb + "</option>")
               }
             });
            });

       })
}


$(document).ready(() => {
  $("#contenido").off("click", "a.editar");
  $("#contenido").off("click", "button#actualizar");
  $("#contenido").off("click","a.borrar");
  $("#contenido").off("click","button#nuevo");
  $("#contenido").off("click","button#grabar");
  $("#titulo").html("Listado de Contratos");
  dt = $("#tabla").DataTable({
        "ajax": "php/contratos/controladorContratos.php?accion=listar",
        "columns": [
            { "data": "contra_cod"} ,
            { "data": "prove_nomb" },
            { "data": "emple_nomb" },
            { "data": "contra_ini" },
            { "data": "contra_fin" },
            { "data": "contra_desc" },
            { "data": "DiasEstancia" },
            
           /* if({ "data": "DiasEstancia" } >=0 && { "data": "DiasEstancia" } <= 45){
                { "data": "Esta por acabarse" },
            }else if(){

            }*/

        ]
  });
  contratos();
});