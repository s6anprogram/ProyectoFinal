var dt;

function sucursales(){
    $("#contenido").on("click","button#actualizar",function(){
         var datos=$("#fsucursales").serialize();
         $.ajax({
            type:"get",
            url:"./php/sucursales/controladorSucursales.php",
            data: datos,
            dataType:"json"
          }).done(function( resultado ) {
              if(resultado.respuesta){
                swal(
                    'Actualizado!',
                    'Se actualizaron los datos correctamente',
                    'success'
                )     
                dt.ajax.reload();
                $("#titulo").html("Listado de Sucursales");
                $("#nuevo-editar").html("")
                $("#nuevo-editar").removeClass("show");
                $("#nuevo-editar").addClass("hide");
                $("#Sucursales").removeClass("hide");
                $("#Sucursales").addClass("show");
             } else {
                swal({
                  type: 'error',
                  title: 'Oops...',
                  text: 'Something went wrong!'                         
                })
            }
        });
    })

    $("#contenido").on("click","a.borrar",function(){
        //Recupera datos del formulario
        var codigo = $(this).data("codigo");

        swal({
              title: '¿Está seguro?',
              text: "¿Realmente desea borrar la sucursal con codigo : " + codigo + " ?",
              type: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Si, Borrarlo!'
        }).then((decision) => {
                if (decision.value) {

                    var request = $.ajax({
                        method: "get",
                        url: "./php/sucursales/controladorSucursales.php",
                        data: {codigo: codigo, accion:'borrar'},
                        dataType: "json"
                    })

                    request.done(function( resultado ) {
                        if(resultado.respuesta == 'correcto'){
                            swal(
                                'Borrado!',
                                'El sucursales con codigo : ' + codigo + ' fue borrado',
                                'success'
                            )     
                            dt.ajax.reload();                            
                        } else {
                            swal({
                              type: 'error',
                              title: 'Oops...',
                              text: 'Something went wrong!'                         
                            })
                        }
                    });
                     
                    request.fail(function( jqXHR, textStatus ) {
                        swal({
                          type: 'error',
                          title: 'Oops...',
                          text: 'Something went wrong!' + textStatus                          
                        })
                    });
                }
        })

    });

    $("#contenido").on("click","button.btncerrar2",function(){
        $("#titulo").html("Listado de Sucursales");
        $("#nuevo-editar").html("");
        $("#nuevo-editar").removeClass("show");
        $("#nuevo-editar").addClass("hide");
        $("#Sucursales").removeClass("hide");
        $("#Sucursales").addClass("show");

    })

    $("#contenido").on("click","button.btncerrar",function(){
        $("#contenedor").removeClass("show");
        $("#contenedor").addClass("hide");
        $("#contenido").html('');
    })

    $("#contenido").on("click","button#nuevo",function(){
        $("#titulo").html("Nuevas Sucursales");
        $("#nuevo-editar" ).load("./php/sucursales/nuevoSucursales.php"); 
        $("#nuevo-editar").removeClass("hide");
        $("#nuevo-editar").addClass("show");
        $("#Sucursales").removeClass("show");
        $("#Sucursales").addClass("hide");
        $.ajax({
             type:"get",
             url:"./php/empresas/controladorEmpresas.php",
             data: {accion:'listar'},
             dataType:"json"
           }).done(function( resultado ) {   
              //console.log(resultado.data)           
              $("#empre_cod option").remove()       
              $("#empre_cod").append("<option selecte value=''>Seleccione una Empresa</option>")
              $.each(resultado.data, function (index, value) { 
                $("#empre_cod").append("<option value='" + value.empre_cod + "'>" + value.empre_nomb + "</option>")
              });
           });
    })

    $("#contenido").on("click","button#grabar",function(){
        /*var comu_codi = $("#comu_codi").attr("value");
        var comu_nomb = $("#comu_nomb").attr("value");
        var muni_codi = $("#muni_codi").attr("value");
        var datos = "comu_codi="+comu_codi+"&comu_nomb="+comu_nomb+"&muni_codi="+muni_codi;*/
      
      var datos=$("#fsucursales").serialize();
       $.ajax({
            type:"get",
            url:"./php/sucursales/controladorSucursales.php",
            data: datos,
            dataType:"json"
          }).done(function( resultado ) {
              if(resultado.respuesta){
                swal(
                    'Grabado!!',
                    'El registro se grabó correctamente',
                    'success'
                )     
                dt.ajax.reload();
                $("#titulo").html("Listado de Sucursales");
                $("#nuevo-editar").html("");
                $("#nuevo-editar").removeClass("show");
                $("#nuevo-editar").addClass("hide");
                $("#sucursales").removeClass("hide");
                $("#sucursales").addClass("show");
             } else {
                swal({
                  type: 'error',
                  title: 'Oops...',
                  text: 'Something went wrong!'                         
                })
            }
        });
    });


    $("#contenido").on("click","a.editar",function(){
       $("#titulo").html("Editar Sucursal");
       //Recupera datos del fromulario
       var codigo = $(this).data("codigo");
       var empresas;
        $("#nuevo-editar").load("./php/sucursales/editarSucursales.php");
        $("#nuevo-editar").removeClass("hide");
        $("#nuevo-editar").addClass("show");
        $("#Sucursales").removeClass("show");
        $("#Sucursales").addClass("hide");
       $.ajax({
           type:"get",
           url:"./php/sucursales/controladorSucursales.php",
           data: {codigo: codigo, accion:'consultar'},
           dataType:"json"
           }).done(function( sucursales ) {        
                if(sucursales.respuesta === "no existe"){
                    swal({
                      type: 'error',
                      title: 'Oops...',
                      text: 'Sucursal no existe!!!!!'                         
                    })
                } else {
                    $("#sucur_cod").val(sucursales.codigo);                   
                    $("#sucur_nomb").val(sucursales.nombre);
                    $("#sucur_tel").val(sucursales.telefono);                   
                    $("#sucur_dir").val(sucursales.direccion);
                    empresas = sucursales.empresa;                                      
                }
           }); 
           $.ajax({
             type:"get",
             url:"./php/empresas/controladorEmpresas.php",
             data: {accion:'listar'},
             dataType:"json"
           }).done(function( resultado ) {                     
              $("#empre_cod option").remove();
              $.each(resultado.data, function (index, value) { 
                
                if(empresas === value.empre_cod){
                  $("#empre_cod").append("<option selected value='" + value.empre_cod + "'>" + value.empre_nomb + "</option>")
                }else {
                  $("#empre_cod").append("<option value='" + value.empre_cod + "'>" + value.empre_nomb + "</option>")
                }
              });
           });            
       })
}


$(document).ready(() => {
  $("#contenido").off("click", "a.editar");
  $("#contenido").off("click", "button#actualizar");
  $("#contenido").off("click","a.borrar");
  $("#contenido").off("click","button#nuevo");
  $("#contenido").off("click","button#grabar");
  $("#titulo").html("Listado de Sucursales");
  dt = $("#tabla").DataTable({
        "ajax": "php/sucursales/controladorSucursales.php?accion=listar",
        "columns": [
            { "data": "sucur_cod"} ,
            { "data": "sucur_nomb" },
            { "data": "sucur_tel"} ,
            { "data": "sucur_dir" },
            { "data": "empre_nomb" },
        ]
  });
  sucursales();
});