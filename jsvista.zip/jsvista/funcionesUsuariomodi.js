var dt;

function usuario(){
    $("#contenido").on("click","button#actualizar",function(){
         var datos=$("#fusuario").serialize();
         $.ajax({
            type:"get",
            url:"./php/usuario/controladorUsuario.php",
            data: datos,
            dataType:"json"
          }).done(function( resultado ) {
              if(resultado.respuesta){
                swal(
                    'Actualizado!',
                    'Se actualizaron los datos correctamente',
                    'success'
                )     
                dt.ajax.reload();
                $("#titulo").html("Listado Usuario");
                $("#nuevo-editar").html("");
                $("#nuevo-editar").removeClass("show");
                $("#nuevo-editar").addClass("hide");
                $("#usuario").removeClass("hide");
                $("#usuario").addClass("show");
             } else {
                swal({
                  type: 'error',
                  title: 'Oops...',
                  text: 'Something went wrong!'                         
                })
            }
        });
    })

    $("#contenido").on("click","a.borrar",function(){
        //Recupera datos del formulario
        var codigo = $(this).data("codigo");

        swal({
              title: '¿Está seguro?',
              text: "¿Realmente desea borrar el usuario con codigo : " + codigo + " ?",
              type: 'warning',
              showCancelButton: true,
              confirmButtonColor: '#3085d6',
              cancelButtonColor: '#d33',
              confirmButtonText: 'Si, Borrarlo!'
        }).then((decision) => {
                if (decision.value) {

                    var request = $.ajax({
                        method: "get",
                        url: "./php/usuario/controladorUsuario.php",
                        data: {codigo: codigo, accion:'borrar'},
                        dataType: "json"
                    })

                    request.done(function( resultado ) {
                        if(resultado.respuesta == 'correcto'){
                            swal(
                                'Borrado!',
                                'El usuario con codigo : ' + codigo + ' fue borrado',
                                'success'
                            )     
                            dt.ajax.reload();                            
                        } else {
                            swal({
                              type: 'error',
                              title: 'Oops...',
                              text: 'Something went wrong!'                         
                            })
                        }
                    });
                     
                    request.fail(function( jqXHR, textStatus ) {
                        swal({
                          type: 'error',
                          title: 'Oops...',
                          text: 'Something went wrong!' + textStatus                          
                        })
                    });
                }
        })

    });

    $("#contenido").on("click","button.btncerrar2",function(){
        $("#titulo").html("Listado Usuario");
        $("#nuevo-editar").html("");
        $("#nuevo-editar").removeClass("show");
        $("#nuevo-editar").addClass("hide");
        $("#usuario").removeClass("hide");
        $("#usuario").addClass("show");

    })

    $("#contenido").on("click","button.btncerrar",function(){
        $("#contenedor").removeClass("show");
        $("#contenedor").addClass("hide");
        $("#contenido").html('');
    })

    $("#contenido").on("click","button#nuevo",function(){
        $("#titulo").html("Nuevo Usuario");
        var rol;
        $("#nuevo-editar" ).load("./php/usuario/nuevoUsuario.php"); 
        $("#nuevo-editar").removeClass("hide");
        $("#nuevo-editar").addClass("show");
        $("#usuario").removeClass("show");
        $("#usuario").addClass("hide");
          $.ajax({
            type:"get",
            url:"./php/rol/controladorRol.php",
            data: {accion:'listar'},
            dataType:"json"
          }).done(function( resultado ) {   
             //console.log(resultado.data)           
             $("#rol_cod option").remove()       
             $("#rol_cod").append("<option selecte value=''>Seleccione un rol</option>")
             $.each(resultado.data, function (index, value) { 
               $("#rol_cod").append("<option value='" + value.rol_cod + "'>" + value.rol_nomb + "</option>")
             });
          }); 
    })

    $("#contenido").on("click","button#grabar",function(){
        /*var comu_codi = $("#comu_codi").attr("value");
        var comu_nomb = $("#comu_nomb").attr("value");
        var muni_codi = $("#muni_codi").attr("value");
        var datos = "comu_codi="+comu_codi+"&comu_nomb="+comu_nomb+"&muni_codi="+muni_codi;*/
      
      var datos=$("#fusuario").serialize();
       $.ajax({
            type:"get",
            url:"./php/usuario/controladorUsuario.php",
            data: datos,
            dataType:"json"
          }).done(function( resultado ) {
              if(resultado.respuesta){
                swal(
                    'Grabado!!',
                    'El registro se grabó correctamente',
                    'success'
                )     
                dt.ajax.reload();
                $("#titulo").html("Listado usuario");
                $("#nuevo-editar").html("");
                $("#nuevo-editar").removeClass("show");
                $("#nuevo-editar").addClass("hide");
                $("#usuario").removeClass("hide");
                $("#usuario").addClass("show");
             } else {
                swal({
                  type: 'error',
                  title: 'Oops...',
                  text: 'Something went wrong!'                         
                })
            }
        });
    });


    $("#contenido").on("click","a.editar",function(){
       $("#titulo").html("Editar usuario");
       //Recupera datos del fromulario
       var codigo = $(this).data("codigo");
       var direccion;
       var rol;
        $("#nuevo-editar").load("./php/usuario/editarUsuario.php");
        $("#nuevo-editar").removeClass("hide");
        $("#nuevo-editar").addClass("show");
        $("#usuario").removeClass("show");
        $("#usuario").addClass("hide");
       $.ajax({
           type:"get",
           url:"./php/usuario/controladorUsuario.php",
           data: {codigo: codigo, accion:'consultar'},
           dataType:"json"
           }).done(function( usuario ) {        
                if(usuario.respuesta === "no existe"){
                    swal({
                      type: 'error',
                      title: 'Oops...',
                      text: 'El usuario no existe!!!!!'                         
                    })
                } else {
                    $("#usu_cod").val(usuario.codigo);                   
                    $("#usu_nomb").val(usuario.nombre);
                    $("#usu_user").val(usuario.usuario);
                    $("#usu_pass").val(usuario.password);                   
                    $("#usu_correo").val(usuario.correo);    
                    $("#usu_tel").val(usuario.telefono);   
                    rol = usuario.rol;                
                }
           });  
           
           $.ajax({
            type:"get",
            url:"./php/rol/controladorRol.php",
            data: {accion:'listar'},
            dataType:"json"
          }).done(function( resultado ) {                     
             $("#rol_cod option").remove();
             $.each(resultado.data, function (index, value) { 
               
               if(rol === value.rol_cod){
                 $("#rol_cod").append("<option selected value='" + value.rol_cod + "'>" + value.rol_nomb + "</option>")
               }else {
                 $("#rol_cod").append("<option value='" + value.rol_cod + "'>" + value.rol_nomb + "</option>")
               }
             });
            });

       })
}


$(document).ready(() => {
  $("#contenido").off("click", "a.editar");
  $("#contenido").off("click", "button#actualizar");
  $("#contenido").off("click","a.borrar");
  $("#contenido").off("click","button#nuevo");
  $("#contenido").off("click","button#grabar");
  $("#titulo").html("Listado de Usuarios");
  dt = $("#tabla").DataTable({
        "ajax": "php/usuariomodi/controladorUsuario.php?accion=listar2",
        "columns": [
            { "data": "usu_cod"} ,
            { "data": "usu_nomb" },
            { "data": "usu_user" },
            { "data": "usu_pass" },
            { "data": "usu_correo" },
            { "data": "usu_tel" },
            { "data": "rol_nomb" },
            
            { "data": "usu_cod",
                render: function (data) {
                          return '<a href="#" data-codigo="'+ data + 
                                 '" class="btn btn-info btn-sm editar"> <i class="fa fa-edit"></i></a>';
                }
            }
        ]
  });
  usuario();
});