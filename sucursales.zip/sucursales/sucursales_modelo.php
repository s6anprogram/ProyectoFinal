<?php
	require_once('../modeloAbstractoDB.php');
	class Sucursales extends ModeloAbstractoDB {
		private $sucur_cod;
		private $sucur_nomb;
		private $sucur_tel;
		private $sucur_dir;
		private $empre_cod;
		
		function __construct() {
			//$this->db_name = '';
		}
		
		public function getsucur_cod(){
			return $this->sucur_cod;
		}

		public function getsucur_nomb(){
			return $this->sucur_nomb;
		}
		
		public function getsucur_tel(){
			return $this->sucur_tel;
		} 

		public function getsucur_dir(){
			return $this->sucur_dir;
		}  

		public function getempre_cod(){
			return $this->empre_cod;
		}   

		public function consultar($sucur_cod='') {
			if($sucur_cod != ''):
				$this->query = "
				SELECT sucur_cod, sucur_nomb, sucur_tel, sucur_dir, empre_cod 
				FROM tb_sucursales 
				WHERE sucur_cod = '$sucur_cod'
				";
				$this->obtener_resultados_query();
			endif;
			if(count($this->rows) == 1):
				foreach ($this->rows[0] as $propiedad=>$valor):
					$this->$propiedad = $valor;
				endforeach;
			endif;
		}
		
		public function lista() {
			$this->query = "
			SELECT sucur_cod, sucur_nomb, sucur_tel, sucur_dir, c.empre_nomb 
				FROM tb_sucursales as em INNER JOIN tb_empresas as c 
				ON (em.empre_cod = c.empre_cod) 
				ORDER BY sucur_cod
				";
			$this->obtener_resultados_query();
			return $this->rows;
		}

		public function lista2($variable) {
			$this->query = "
			SELECT sucur_cod, sucur_nomb, sucur_tel, sucur_dir, c.empre_nomb 
				FROM tb_sucursales as em INNER JOIN tb_empresas as c 
				ON (em.empre_cod = c.empre_cod) 
				ORDER BY sucur_cod
				";
			$this->obtener_resultados_query();
			return $this->rows;
		}
		
		public function nuevo($datos=array()) {
			if(array_key_exists('sucur_cod', $datos)):
				foreach ($datos as $campo=>$valor):
					$$campo = $valor;
				endforeach;
				$this->query = "
				INSERT INTO tb_sucursales
				(sucur_nomb,sucur_tel,sucur_dir,empre_cod)
				VALUES
				('$sucur_nomb','$sucur_tel','$sucur_dir','$empre_cod')
				";
				$resultado = $this->ejecutar_query_simple();
				return $resultado;
			endif;
		}
		
		public function editar($datos=array()) {
			foreach ($datos as $campo=>$valor):
				$$campo = $valor;
			endforeach;
			$this->query = "
			UPDATE tb_sucursales
			SET sucur_nomb='$sucur_nomb',
			sucur_tel='$sucur_tel',
			sucur_dir='$sucur_dir',
			empre_cod='$empre_cod'
			WHERE sucur_cod  = '$sucur_cod '
			";
			$resultado = $this->ejecutar_query_simple();
			return $resultado;
		}
		
		public function borrar($sucur_cod='') {
			$this->query = "
			DELETE FROM tb_sucursales
			WHERE sucur_cod = '$sucur_cod'
			";
			$resultado = $this->ejecutar_query_simple();

			return $resultado;
		}
		
		function __destruct() {
			//unset($this);
		}
	}
?>