<?php
 
require_once 'sucursales_modelo.php';
$datos = $_GET;
switch ($_GET['accion']){
    case 'editar':
        $sucursales = new Sucursales();
		$resultado = $sucursales->editar($datos);
        $respuesta = array(
                'respuesta' => $resultado
            );
        echo json_encode($respuesta);
        break;
    case 'nuevo':
        $sucursales = new Sucursales();
		$resultado = $sucursales->nuevo($datos);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;
    case 'borrar':
		$sucursales = new Sucursales();
		$resultado = $sucursales->borrar($datos['codigo']);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'consultar':
        $sucursales = new Sucursales();
        $sucursales->consultar($datos['codigo']);

        if($sucursales->getsucur_cod() == null) {
            $respuesta = array(
                'respuesta' => 'no existe'
            );
        }  else {
            $respuesta = array(
                'codigo' => $sucursales->getsucur_cod(),
                'nombre' => $sucursales->getsucur_nomb(),
                'telefono' =>$sucursales->getsucur_tel(),
                'direccion' =>$sucursales->getsucur_dir(),
                'empresa' =>$sucursales->getempre_cod(),
                'respuesta' =>'existe'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'listar':
        $sucursales = new Sucursales();
        $listado = $sucursales->lista();        
        echo json_encode(array('data'=>$listado), JSON_UNESCAPED_UNICODE);
        break;

        case 'listar2':
        $variable = 0;
        $sucursales = new Sucursales();
        $listado = $sucursales->lista2($variable);        
        echo json_encode(array('data'=>$listado), JSON_UNESCAPED_UNICODE);
        break;
}
?>
