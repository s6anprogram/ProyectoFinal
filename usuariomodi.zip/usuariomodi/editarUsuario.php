   <div id="seccion-usuario">
    <div class="box-header">
    	<i class="fa fa-building" aria-hidden="true">Gestion de Usuario</i>
        
        <!-- tools box -->
        <div class="pull-right box-tools">
        	<button class="btn btn-info btn-sm btncerrar2" data-toggle="tooltip" title="Cerrar"><i class="fa fa-times"></i></button>
        </div><!-- /. tools -->
    </div>
    <div class="box-body">

		<div align ="center">
				<div id="actual"> 
				</div>
		</div>

        <div class="panel-group"><div class="panel panel-info">
            <div class="panel-heading">Datos</div>
            <div class="panel-body">
    
                <form class="form-horizontal" role="form"  id="fusuario">


 					<div class="form-group">
                        <label class="control-label col-sm-2" for="usu_cod">Codigo:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="usu_cod" name="usu_cod" placeholder="Ingrese Codigo"
                            value = "" readonly="true">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-sm-2" for="usu_nomb">Nombre:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="usu_nomb" name="usu_nomb" placeholder="Ingrese Nombre"
                            value = "">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-sm-2" for="usu_user">Usuario:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="usu_user" name="usu_user" placeholder="Ingrese Usuario"
                            value = "">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label class="control-label col-sm-2" for="usu_pass">Contraseña:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="usu_pass" name="usu_pass" placeholder="Ingrese Contraseña"
                            value = "">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-sm-2" for="usu_correo">Correo:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="usu_correo" name="usu_correo" placeholder="Ingrese su Correo"
                            value = "">
                        </div>
                    </div>                     

                    <div class="form-group">
                        <label class="control-label col-sm-2" for="usu_tel">Telefono:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="usu_tel" name="usu_tel" placeholder="Ingrese Telefono"
                            value = "">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-sm-2" for="rol_cod">Rol:</label>
                        <div class="col-sm-10">
                            <select class="form-control" id="rol_cod" name="rol_cod">
                            
                            </select>
                        </div>
                    </div>             
					

					 <div class="form-group">        
                        <div class="col-sm-offset-2 col-sm-10">
                            <button type="button" id="actualizar" data-toggle="tooltip" title="Actualizar Empleado" class="btn btn-info">Actualizar</button>
                            <button type="button" id="cancelar" data-toggle="tooltip" title="Cancelar Edición" class="btn btn-success btncerrar2"> Cancelar </button>
                        </div>

                    </div>                    

					<input type="hidden" id="editar" value="editar" name="accion"/>
			</fieldset>

		</form>
	</div>
    <input type="hidden" id="pagina" value="editar" name="editar"/>
</div>