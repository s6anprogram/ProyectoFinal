<?php
 
require_once 'contratos_modelo.php';
$datos = $_GET;
switch ($_GET['accion']){
    case 'editar':
        $contratos = new Contratos();
        $resultado = $contratos->editar($datos);
        $respuesta = array(
                'respuesta' => $resultado
            );
        echo json_encode($respuesta);
        break;
    case 'nuevo':
        $contratos = new Contratos();
        $resultado = $contratos->nuevo($datos);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;
    case 'borrar':
        $contratos = new Contratos();
        $resultado = $contratos->borrar($datos['codigo']);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'consultar':
        $contratos = new Contratos();
        $contratos->consultar($datos['codigo']);

        if($contratos->getcontra_cod() == null) {
            $respuesta = array(
                'respuesta' => 'no existe'
            );
        }  else {
            $respuesta = array(
                'codigo' => $contratos->getcontra_cod(),
                'proveedor' => $contratos->getprove_cod(),
                'empleado' => $contratos->getemple_cod(),
                'inicio' => $contratos->getcontra_ini(),
                'fin' => $contratos->getcontra_fin(),
                'descripcion' => $contratos->getcontra_desc(),
                'respuesta' =>'existe'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'listar':
        $contratos = new Contratos();
        $listado = $contratos->lista();        
        echo json_encode(array('data'=>$listado), JSON_UNESCAPED_UNICODE);
        break;

        case 'listar2':
        $variable = 0;
        $contratos = new Contratos();
        $listado = $contratos->lista2($variable);        
        echo json_encode(array('data'=>$listado), JSON_UNESCAPED_UNICODE);
        break;
}
?>
