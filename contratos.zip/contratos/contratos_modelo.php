<?php
	require_once('../modeloAbstractoDB.php');
	class Contratos extends ModeloAbstractoDB {
		public $contra_cod; 	
        public $prove_cod;
        public $emple_cod;
        public $contra_ini;
        public $contra_fin;
        public $contra_desc;
        
		
		function __construct() {
			//$this->db_name = '';
		}
		
		public function getcontra_cod(){
			return $this->contra_cod;
		}

		public function getprove_cod(){
			return $this->prove_cod;
        }
        
        public function getemple_cod(){
			return $this->emple_cod;
        }
        
        public function getcontra_ini(){
			return $this->contra_ini;
        }
        
        public function getcontra_fin(){
			return $this->contra_fin;
        }
        
        public function getcontra_desc(){
			return $this->contra_desc;
		}

          

		public function consultar($contra_cod='') {
			if($contra_cod != ''):
				$this->query = "
				SELECT contra_cod,prove_cod,emple_cod,contra_ini, contra_fin, contra_desc 
				FROM tb_contratos
				WHERE contra_cod = '$contra_cod' order by contra_cod
				";
				$this->obtener_resultados_query();
			endif;
			if(count($this->rows) == 1):
				foreach ($this->rows[0] as $propiedad=>$valor):
					$this->$propiedad = $valor;
				endforeach;
			endif;
		}
		
		public function lista() {
			$this->query = "
			SELECT contra_cod,a.prove_nomb,r.emple_nomb, contra_ini,contra_fin,contra_desc, TIMESTAMPDIFF(DAY, now(), contra_fin) as DiasEstancia, (case  when (TIMESTAMPDIFF(DAY, now(), contra_fin))>=0 and (TIMESTAMPDIFF(DAY, now(), contra_fin))<=30 then 'Pronto Acabara' else '' end) as estado
            FROM tb_contratos as s
            INNER JOIN tb_proveedores as a ON (s.prove_cod = a.prove_cod)
            INNER JOIN tb_empleados as r ON (s.emple_cod = r.emple_cod)
            ORDER BY contra_cod
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}

		public function lista2($variable) {
			$this->query = "
			SELECT contra_cod,a.prove_nomb,r.emple_nomb, contra_ini,contra_fin,contra_desc 
            FROM tb_contratos as s
            INNER JOIN tb_proveedores as a ON (s.prove_cod = a.prove_cod)
            INNER JOIN tb_empleados as r ON (s.emple_cod = r.emple_cod)
            ORDER BY contra_cod
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}

		
		public function nuevo($datos=array()) {
			if(array_key_exists('contra_cod', $datos)):
				foreach ($datos as $campo=>$valor):
					$$campo = $valor;
				endforeach;
				$this->query = "
				INSERT INTO tb_contratos
				(prove_cod,emple_cod,contra_ini,contra_fin,contra_desc)
				VALUES
				('$prove_cod','$emple_cod','$contra_ini','$contra_fin','$contra_desc')
				
				";
				$resultado = $this->ejecutar_query_simple();
				return $resultado;
			endif;
		}
		
		public function editar($datos=array()) {
			foreach ($datos as $campo=>$valor):
				$$campo = $valor;
			endforeach;
			$this->query = "
			UPDATE tb_contratos
            SET prove_cod='$prove_cod',
			emple_cod='$emple_cod',
			contra_ini='$contra_ini',
			contra_fin='$contra_fin',
			contra_desc='$contra_desc' 
			WHERE contra_cod = '$contra_cod'
			";
			$resultado = $this->ejecutar_query_simple();
			return $resultado;
		}
		
		public function borrar($contra_cod='') {
			$this->query = "
			DELETE FROM tb_contratos
			WHERE contra_cod = '$contra_cod'
			";
			$resultado = $this->ejecutar_query_simple();

			return $resultado;
		}
		
		function __destruct() {
			//unset($this);
		}
	}
?>