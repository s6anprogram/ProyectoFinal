<?php
include 'db.php';

class User extends DB{
    private $usu_nomb;
    private $usu_user;
    private $usu_cod;
    private $rol_cod;


    public function userExists($user, $pass){
        $md5pass = md5($pass);
        $query = $this->connect()->prepare('SELECT * FROM tb_usuarios WHERE usu_user = :user AND usu_pass = :pass');
        $query->execute(['user' => $user, 'pass' => $md5pass]);

        if($query->rowCount()){
            return true;

        }else{
            return false;
        }
    }

    public function setUser($user){
        $query = $this->connect()->prepare('SELECT * FROM tb_usuarios WHERE usu_user = :user');
        $query->execute(['user' => $user]);
        
        foreach ($query as $currentUser) {
            $this->usu_nomb = $currentUser['usu_nomb'];
            $this->usu_user = $currentUser['usu_user'];
            $this->usu_cod = $currentUser['usu_cod'];
            $this->rol_cod = $currentUser['rol_cod'];
            
             
          //  $this->usu_cod = $currentUser['usu_cod'];
          //  $_SESSION['usu_cod'] = $usu_cod;
            
        }
    }

    public function getUsuCod(){
        return $this->usu_cod;
    }

    public function getNombre(){
        return $this->usu_nomb;
    }

    public function getRol(){
        return $this->rol_cod;
    }
}

?>