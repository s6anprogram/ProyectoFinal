   <div id="seccion-empleado">
    <div class="box-header">
    	<i class="fa fa-building" aria-hidden="true">Gestion de Empleado</i>
        
        <!-- tools box -->
        <div class="pull-right box-tools">
        	<button class="btn btn-info btn-sm btncerrar2" data-toggle="tooltip" title="Cerrar"><i class="fa fa-times"></i></button>
        </div><!-- /. tools -->
    </div>
    <div class="box-body">

		<div align ="center">
				<div id="actual"> 
				</div>
		</div>

        <div class="panel-group"><div class="panel panel-info">
            <div class="panel-heading">Datos</div>
            <div class="panel-body">
    
                <form class="form-horizontal" role="form"  id="fempleado">


 					<div class="form-group">
                        <label class="control-label col-sm-2" for="emple_cod">Codigo:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="emple_cod" name="emple_cod" placeholder="Ingrese Codigo"
                            value = "" readonly="true">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-sm-2" for="emple_nomb">Nombre:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="emple_nomb" name="emple_nomb" placeholder="Ingrese Nombre"
                            value = "">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label class="control-label col-sm-2" for="emple_edad">Edad:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="emple_edad" name="emple_edad" placeholder="Ingrese Edad"
                            value = "">
                        </div>
                    </div>

                    

                    <div class="form-group">
                        <label class="control-label col-sm-2" for="emple_tel">Telefono:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="emple_tel" name="emple_tel" placeholder="Ingrese Telefono"
                            value = "">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-sm-2" for="emple_dir">Direccion:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="emple_dir" name="emple_dir" placeholder="Ingrese Direccion"
                            value = "" readonly="true">
                        </div>
                    </div>


                    <div class="form-group">
                        <label class="control-label col-sm-2" for="emple_correo">Correo:</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="emple_correo" name="emple_correo" placeholder="Ingrese Correo"
                            value = "">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-sm-2" for="proce_cod">Proceso:</label>
                        <div class="col-sm-10">
                            <select class="form-control" id="proce_cod" name="proce_cod">
                            
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-sm-2" for="sucur_cod">Sucursal:</label>
                        <div class="col-sm-10">
                            <select class="form-control" id="sucur_cod" name="sucur_cod">
                            
                            </select>
                        </div>
                    </div>

                    
					

					 <div class="form-group">        
                        <div class="col-sm-offset-2 col-sm-10">
                            <button type="button" id="actualizar" data-toggle="tooltip" title="Actualizar Empleado" class="btn btn-info">Actualizar</button>
                            <button type="button" id="cancelar" data-toggle="tooltip" title="Cancelar Edición" class="btn btn-success btncerrar2"> Cancelar </button>
                        </div>

                    </div>                    

					<input type="hidden" id="editar" value="editar" name="accion"/>
			</fieldset>

		</form>
	</div>
    <input type="hidden" id="pagina" value="editar" name="editar"/>
</div>