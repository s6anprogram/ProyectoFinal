<?php
 
require_once 'empleado_modelo.php';
$datos = $_GET;
switch ($_GET['accion']){
    case 'editar':
        $empleado = new Empleado();
        $resultado = $empleado->editar($datos);
        $respuesta = array(
                'respuesta' => $resultado
            );
        echo json_encode($respuesta);
        break;
    case 'nuevo':
        $empleado = new Empleado();
        $resultado = $empleado->nuevo($datos);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;
    case 'borrar':
        $empleado = new Empleado();
        $resultado = $empleado->borrar($datos['codigo']);
        if($resultado > 0) {
            $respuesta = array(
                'respuesta' => 'correcto'
            );
        }  else {
            $respuesta = array(
                'respuesta' => 'error'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'consultar':
        $empleado = new Empleado();
        $empleado->consultar($datos['codigo']);

        if($empleado->getemple_cod() == null) {
            $respuesta = array(
                'respuesta' => 'no existe'
            );
        }  else {
            $respuesta = array(
                'codigo' => $empleado->getemple_cod(),
                'nombre' => $empleado->getemple_nomb(),
                'edad' => $empleado->getemple_edad(),
                'telefono' => $empleado->getemple_tel(),
                'direccion' => $empleado->getemple_dir(),
                'correo' => $empleado->getemple_correo(),
                'proceso' => $empleado->getproce_cod(),
                'sucursal' => $empleado->getsucur_cod(),
                'respuesta' =>'existe'
            );
        }
        echo json_encode($respuesta);
        break;

    case 'listar':
        $empleado = new Empleado();
        $listado = $empleado->lista();        
        echo json_encode(array('data'=>$listado), JSON_UNESCAPED_UNICODE);
        break;

        case 'listar2':
        $variable = 0;
        $empleado = new Empleado();
        $listado = $empleado->lista2($variable);        
        echo json_encode(array('data'=>$listado), JSON_UNESCAPED_UNICODE);
        break;
}
?>
