<?php
	require_once('../modeloAbstractoDB.php');
	class Empleado extends ModeloAbstractoDB {
		public $emple_cod; 	
        public $emple_nomb;
        public $emple_edad;
        public $emple_tel;
        public $emple_dir;
        public $emple_correo;
        public $proce_cod;
        public $sucur_cod;
		
		function __construct() {
			//$this->db_name = '';
		}
		
		public function getemple_cod(){
			return $this->emple_cod;
		}

		public function getemple_nomb(){
			return $this->emple_nomb;
        }
        
        public function getemple_edad(){
			return $this->emple_edad;
        }
        
        public function getemple_tel(){
			return $this->emple_tel;
        }
        
        public function getemple_dir(){
			return $this->emple_dir;
        }
        
        public function getemple_correo(){
			return $this->emple_correo;
		}
        
        public function getproce_cod(){
			return $this->proce_cod;
        }
        
        public function getsucur_cod(){
			return $this->sucur_cod;
		}
		
          

		public function consultar($emple_cod='') {
			if($emple_cod != ''):
				$this->query = "
				SELECT emple_cod,emple_nomb,emple_edad,emple_tel, emple_dir, emple_correo, proce_cod, sucur_cod 
				FROM tb_empleados
				WHERE emple_cod = '$emple_cod' order by emple_cod
				";
				$this->obtener_resultados_query();
			endif;
			if(count($this->rows) == 1):
				foreach ($this->rows[0] as $propiedad=>$valor):
					$this->$propiedad = $valor;
				endforeach;
			endif;
		}
		
		public function lista() {
			$this->query = "
			SELECT emple_cod,emple_nomb,emple_edad,emple_tel, emple_dir, emple_correo, a.proce_nomb, r.sucur_nomb 
            FROM tb_empleados as s
            INNER JOIN tb_procesos as a ON (s.proce_cod = a.proce_cod)
            INNER JOIN tb_sucursales as r ON (s.sucur_cod = r.sucur_cod)
            ORDER BY emple_cod
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}


		public function lista2($variable) {
			$this->query = "
			SELECT emple_cod,emple_nomb,emple_edad,emple_tel, emple_dir, emple_correo, a.proce_nomb, r.sucur_nomb 
            FROM tb_empleados as s
            INNER JOIN tb_procesos as a ON (s.proce_cod = a.proce_cod)
            INNER JOIN tb_sucursales as r ON (s.sucur_cod = r.sucur_cod)
            ORDER BY emple_cod
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}

		
		public function nuevo($datos=array()) {
			if(array_key_exists('emple_cod', $datos)):
				foreach ($datos as $campo=>$valor):
					$$campo = $valor;
				endforeach;
				$this->query = "
				INSERT INTO tb_empleados
				(emple_nomb,emple_edad,emple_tel,emple_dir,emple_correo,proce_cod,sucur_cod)
				VALUES
				('$emple_nomb','$emple_edad','$emple_tel','$emple_dir','$emple_correo','$proce_cod','$sucur_cod')
				
				";
				$resultado = $this->ejecutar_query_simple();
				return $resultado;
			endif;
		}
		
		public function editar($datos=array()) {
			foreach ($datos as $campo=>$valor):
				$$campo = $valor;
			endforeach;
			$this->query = "
			UPDATE tb_empleados
            SET emple_nomb='$emple_nomb',
			emple_edad='$emple_edad',
			emple_tel='$emple_tel',
			emple_dir='$emple_dir',
			emple_correo='$emple_correo',
            proce_cod='$proce_cod',
            sucur_cod='$sucur_cod'
			WHERE emple_cod = '$emple_cod'
			";
			$resultado = $this->ejecutar_query_simple();
			return $resultado;
		}
		
		public function borrar($emple_cod='') {
			$this->query = "
			DELETE FROM tb_empleados
			WHERE emple_cod = '$emple_cod'
			";
			$resultado = $this->ejecutar_query_simple();

			return $resultado;
		}
		
		function __destruct() {
			//unset($this);
		}
	}
?>