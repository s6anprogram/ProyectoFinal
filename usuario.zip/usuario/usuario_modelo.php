<?php
	require_once('../modeloAbstractoDB.php');
	class Usuario extends ModeloAbstractoDB {
		public $usu_cod; 	
        public $usu_nomb;
        public $usu_user;
        public $usu_pass;
        public $usu_correo;
        public $usu_tel;
        public $rol_cod;

		
		function __construct() {
			//$this->db_name = '';
		}
		
		public function getusu_cod(){
			return $this->usu_cod;
		}

		public function getusu_nomb(){
			return $this->usu_nomb;
		}

		public function getusu_user(){
			return $this->usu_user;
        }

		public function getusu_pass(){
			return $this->usu_pass;
        }
        
        public function getusu_correo(){
			return $this->usu_correo;
        }
        
        public function getusu_tel(){
			return $this->usu_tel;
        }
        
        public function getrol_cod(){
			return $this->rol_cod;
		}
        

		public function consultar($usu_cod='') {
			if($usu_cod != ''):
				$this->query = "
				SELECT usu_cod, usu_nomb, usu_user, usu_pass, usu_correo, usu_tel, rol_cod 
				FROM tb_usuarios
				WHERE usu_cod = '$usu_cod' order by usu_cod
				";
				$this->obtener_resultados_query();
			endif;
			if(count($this->rows) == 1):
				foreach ($this->rows[0] as $propiedad=>$valor):
					$this->$propiedad = $valor;
				endforeach;
			endif;
		}
		
		public function lista() {
			$this->query = "
			SELECT usu_cod, usu_nomb, usu_user, usu_pass, usu_correo, usu_tel, rol_nomb 
            FROM tb_usuarios as s
            INNER JOIN tb_roles as r ON (s.rol_cod = r.rol_cod)
            ORDER BY usu_cod
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}

		public function lista2($variable) {
			$this->query = "
			SELECT usu_cod, usu_nomb, usu_user, usu_pass,usu_correo, usu_tel, rol_nomb 
            FROM tb_usuarios as s
            INNER JOIN tb_roles as r ON (s.rol_cod = r.rol_cod)
            where usu_cod = $variable 
            ORDER BY usu_cod
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}

		
		public function nuevo($datos=array()) {
			if(array_key_exists('usu_cod', $datos)):
				foreach ($datos as $campo=>$valor):
					$$campo = $valor;
				endforeach;
				$this->query = "
				INSERT INTO tb_usuarios
				(usu_nomb,usu_user,usu_pass,usu_correo,usu_tel,rol_cod)
				VALUES
				('$usu_nomb','$usu_user','$usu_pass','$usu_correo','$usu_tel','$rol_cod')
				";
				$resultado = $this->ejecutar_query_simple();
				return $resultado;
			endif;
		}
		
		public function editar($datos=array()) {
			foreach ($datos as $campo=>$valor):
				$$campo = $valor;
			endforeach;
			$this->query = "
			UPDATE tb_usuarios
            SET usu_nomb='$usu_nomb',
            usu_user='$usu_user',
			usu_pass='$usu_pass',
			usu_correo='$usu_correo',
			usu_tel='$usu_tel',
			rol_cod='$rol_cod'
			WHERE usu_cod = '$usu_cod'
			";
			$resultado = $this->ejecutar_query_simple();
			return $resultado;
		}
		
		public function borrar($usu_cod='') {
			$this->query = "
			DELETE FROM tb_usuarios
			WHERE usu_cod = '$usu_cod'
			";
			$resultado = $this->ejecutar_query_simple();

			return $resultado;
		}
		
		function __destruct() {
			//unset($this);
		}
	}
?>