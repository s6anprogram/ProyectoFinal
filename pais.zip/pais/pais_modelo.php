<?php
	require_once('../modeloAbstractoDB.php');
	class Paises extends ModeloAbstractoDB {
		public $pais_cod;
		public $pais_nomb; 
		
		function __construct() {
			//$this->db_name = '';
		}
		
		public function getpais_cod(){
			return $this->pais_cod;
		}
		
		public function getpais_nomb(){
			return $this->pais_nomb;
		}
        
          

		public function consultar($pais_cod='') {
			if($pais_cod != ''):
				$this->query = "
				SELECT pais_cod, pais_nomb 
				FROM tb_paises
				WHERE pais_cod = '$pais_cod' order by pais_cod
				";
				$this->obtener_resultados_query();
			endif;
			if(count($this->rows) == 1):
				foreach ($this->rows[0] as $propiedad=>$valor):
					$this->$propiedad = $valor;
				endforeach;
			endif;
		}
		
		public function lista() {
			$this->query = "
			SELECT pais_cod, pais_nomb 
			FROM tb_paises
            ORDER BY pais_cod
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}

		public function lista2($variable) {
			$this->query = "
			SELECT pais_cod, pais_nomb 
			FROM tb_paises
            ORDER BY pais_cod
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}
		
		public function nuevo($datos=array()) {
			if(array_key_exists('pais_cod', $datos)):
				foreach ($datos as $campo=>$valor):
					$$campo = $valor;
				endforeach;
				$this->query = "
				INSERT INTO tb_paises
				(pais_nomb)
				VALUES
				('$pais_nomb')
				";
				$resultado = $this->ejecutar_query_simple();
				return $resultado;
			endif;
		}
		
		public function editar($datos=array()) {
			foreach ($datos as $campo=>$valor):
				$$campo = $valor;
			endforeach;
			$this->query = "
			UPDATE tb_paises
			SET pais_nomb='$pais_nomb'
			WHERE pais_cod = '$pais_cod'
			";
			$resultado = $this->ejecutar_query_simple();
			return $resultado;
		}
		
		public function borrar($pais_cod='') {
			$this->query = "
			DELETE FROM tb_paises
			WHERE pais_cod = '$pais_cod'
			";
			$resultado = $this->ejecutar_query_simple();

			return $resultado;
		}
		
		function __destruct() {
			//unset($this);
		}
	}
?>