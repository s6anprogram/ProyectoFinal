<?php
$conexion = mysql_connect('localhost', 'root', '');
mysql_select_db('cedesoft', $conexion);
?>