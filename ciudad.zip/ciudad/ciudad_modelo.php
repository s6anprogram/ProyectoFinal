<?php
	require_once('../modeloAbstractoDB.php');
	class Ciudad extends ModeloAbstractoDB {
		private $ciu_cod;
		private $ciu_nomb;
		private $pais_cod;
		
		
		function __construct() {
			//$this->db_name = '';
		}
		
		public function getciu_cod(){
			return $this->ciu_cod;
		}

		public function getciu_nomb(){
			return $this->ciu_nomb;
		}
		
		public function getpais_cod(){
			return $this->pais_cod;
		}     


		public function consultar($ciu_cod='') {
			if($ciu_cod != ''):
				$this->query = "
				SELECT ciu_cod, ciu_nomb, pais_cod 
				FROM tb_ciudades 
				WHERE ciu_cod = '$ciu_cod' order by ciu_cod
				";
				$this->obtener_resultados_query();
			endif;
			if(count($this->rows) == 1):
				foreach ($this->rows[0] as $propiedad=>$valor):
					$this->$propiedad = $valor;
				endforeach;
			endif;
		}
		
		public function lista() {
			$this->query = "
			SELECT ciu_cod, ciu_nomb, co.pais_nomb 
			FROM tb_ciudades as ci inner join tb_paises as co
			ON (ci.pais_cod = co.pais_cod)
            ORDER BY ciu_cod
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}

		public function lista2($variable) {
			$this->query = "
			SELECT ciu_cod, ciu_nomb, co.pais_nomb 
			FROM tb_ciudades as ci inner join tb_paises as co
			ON (ci.pais_cod = co.pais_cod)
            ORDER BY ciu_cod
			";
			$this->obtener_resultados_query();
			return $this->rows;
		}

		
		
		public function nuevo($datos=array()) {
			if(array_key_exists('ciu_cod', $datos)):
				foreach ($datos as $campo=>$valor):
					$$campo = $valor;
				endforeach;
				$this->query = "
				INSERT INTO tb_ciudades
				(ciu_nomb, pais_cod)
				VALUES
				('$ciu_nomb', '$pais_cod')
				";
				$resultado = $this->ejecutar_query_simple();
				return $resultado;
			endif;
		}
		
		public function editar($datos=array()) {
			foreach ($datos as $campo=>$valor):
				$$campo = $valor;
			endforeach;
			$this->query = "
			UPDATE tb_ciudades
			SET ciu_nomb='$ciu_nomb',
			pais_cod='$pais_cod'
			WHERE ciu_cod = '$ciu_cod'
			";
			$resultado = $this->ejecutar_query_simple();
			return $resultado;
		}
		
		public function borrar($ciu_cod='') {
			$this->query = "
			DELETE FROM tb_ciudades
			WHERE ciu_cod = '$ciu_cod'
			";
			$resultado = $this->ejecutar_query_simple();

			return $resultado;
		}
		
		function __destruct() {
			//unset($this);
		}
	}
?>